from itertools import permutations

def solve_cryptarithmetic():
    # Define the letters and their possible values
    letters = ['S', 'E', 'N', 'D', 'M', 'O', 'R', 'Y']
    digits = range(10)

    # Generate all possible permutations of digits for the letters
    for perm in permutations(digits, len(letters)):
        # Assign each digit to its corresponding letter
        mapping = {letter: digit for letter, digit in zip(letters, perm)}

        # Check if the mapping satisfies the equation
        if mapping['S'] != 0 and mapping['M'] != 0:
            send = mapping['S'] * 1000 + mapping['E'] * 100 + mapping['N'] * 10 + mapping['D']
            more = mapping['M'] * 1000 + mapping['O'] * 100 + mapping['R'] * 10 + mapping['E']
            money = mapping['M'] * 10000 + mapping['O'] * 1000 + mapping['N'] * 100 + mapping['E'] * 10 + mapping['Y']

            if send + more == money:
                # Return the solution
                return {'SEND': send, 'MORE': more, 'MONEY': money}
    return None

# Get the solution
solution = solve_cryptarithmetic()

# Print output
if solution:
    print('(SEND, MORE, MONEY):', (solution['SEND'], solution['MORE'], solution['MONEY']))
else:
    print("No solution found.")