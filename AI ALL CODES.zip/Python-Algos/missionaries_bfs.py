from collections import deque

# Define the initial state
initial_state = (3, 3, 1)

def is_valid(state):
    m_left, c_left, b_left = state
    m_right, c_right, b_right = 3 - m_left, 3 - c_left, 1 - b_left
    return (m_left >= 0 and m_right >= 0 and c_left >= 0 and c_right >= 0 and
            (m_left == 0 or m_left >= c_left) and (m_right == 0 or m_right >= c_right))

def bfs_missionaries_cannibals(initial_state):
    visited = set()
    queue = deque([(initial_state, "")])

    while queue:
        current_state, path = queue.popleft()
        visited.add(current_state)

        if current_state == (0, 0, 0):
            return path

        for move in [(1, 0, 1), (2, 0, 1), (0, 1, 1), (0, 2, 1), (1, 1, 1)]:
            new_state = tuple(sum(x) for x in zip(current_state, move))
            if is_valid(new_state) and new_state not in visited:
                queue.append((new_state, path + f"{move}\n"))

    return "No solution"

# Print the solution path
print(bfs_missionaries_cannibals(initial_state))