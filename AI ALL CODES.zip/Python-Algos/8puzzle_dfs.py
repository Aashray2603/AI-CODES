from collections import deque

# Define the initial state of the puzzle
initial_state = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]

def dfs_8_puzzle(initial_state):
    visited = set()
    stack = deque([(initial_state, "")])

    while stack:
        current_state, path = stack.pop()
        visited.add(tuple(map(tuple, current_state)))

        if current_state == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]:
            return path

        zero_row, zero_col = next((i, j) for i, row in enumerate(current_state) for j, val in enumerate(row) if val == 0)

        for dr, dc, move in [(0, 1, "R"), (0, -1, "L"), (1, 0, "D"), (-1, 0, "U")]:
            new_row, new_col = zero_row + dr, zero_col + dc
            if 0 <= new_row < 3 and 0 <= new_col < 3:
                new_state = [list(row) for row in current_state]
                new_state[zero_row][zero_col], new_state[new_row][new_col] = new_state[new_row][new_col], new_state[zero_row][zero_col]
                if tuple(map(tuple, new_state)) not in visited:
                    stack.append((new_state, path + move))

    return "No solution"

# Print the solution path
print(dfs_8_puzzle(initial_state))