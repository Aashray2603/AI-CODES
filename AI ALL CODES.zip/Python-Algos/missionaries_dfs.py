class Node:
    def __init__(self, state, parent=None, action=None):
        self.state = state
        self.parent = parent
        self.action = action

    def get_path(self):
        path = []
        while self.parent:
            path.append(self.action)
            self = self.parent
        path.reverse()
        return path

    def is_valid(state):
        m_left, c_left, b_left = state
        m_right, c_right, b_right = 3 - m_left, 3 - c_left, 1 - b_left
        return (m_left >= 0 and m_right >= 0 and c_left >= 0 and c_right >= 0 and
                (m_left == 0 or m_left >= c_left) and (m_right == 0 or m_right >= c_right))


def dfs_missionaries_cannibals(initial_state):
    stack = [Node(initial_state)]
    visited = set()
    while stack:
        current_node = stack.pop()
        visited.add(current_node.state)
        if current_node.state == (0, 0, 0):
            return current_node.get_path()
        for move in [(1, 0, 1), (2, 0, 1), (0, 1, 1), (0, 2, 1), (1, 1, 1)]:
            new_state = tuple(sum(x) for x in zip(current_node.state, move))
            if Node.is_valid(new_state) and new_state not in visited:
                stack.append(Node(new_state, current_node, move))
    return "No solution"


# Define the initial state of the problem
initial_state = (3, 3, 1)

# Print the solution path
print(dfs_missionaries_cannibals(initial_state))
