from collections import deque

# Define the capacities of the jugs
jug1_capacity = 4
jug2_capacity = 3

# Define the goal state
goal_quantity = 2

def bfs_water_jug(jug1_capacity, jug2_capacity, goal_quantity):
    visited = set()
    queue = deque([(0, 0, "")])

    while queue:
        jug1, jug2, path = queue.popleft()
        visited.add((jug1, jug2))

        if jug1 == goal_quantity or jug2 == goal_quantity:
            return path

        if (0, jug2) not in visited:
            queue.append((0, jug2, path + "Empty Jug 1\n"))
        if (jug1, 0) not in visited:
            queue.append((jug1, 0, path + "Empty Jug 2\n"))
        if (jug1_capacity, jug2) not in visited:
            queue.append((jug1_capacity, jug2, path + "Fill Jug 1\n"))
        if (jug1, jug2_capacity) not in visited:
            queue.append((jug1, jug2_capacity, path + "Fill Jug 2\n"))

        if jug1 > 0 and (jug1 - min(jug1, jug2_capacity - jug2), jug2 + min(jug1, jug2_capacity - jug2)) not in visited:
            queue.append((jug1 - min(jug1, jug2_capacity - jug2), jug2 + min(jug1, jug2_capacity - jug2), path + "Pour Jug 1 into Jug 2\n"))
        if jug2 > 0 and (jug1 + min(jug2, jug1_capacity - jug1), jug2 - min(jug2, jug1_capacity - jug1)) not in visited:
            queue.append((jug1 + min(jug2, jug1_capacity - jug1), jug2 - min(jug2, jug1_capacity - jug1), path + "Pour Jug 2 into Jug 1\n"))

    return "No solution"

# Print the solution path
print(bfs_water_jug(jug1_capacity, jug2_capacity, goal_quantity))