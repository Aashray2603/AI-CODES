import random
import math


def euclidean_distance(city1, city2):
    """Calculates the Euclidean distance between two cities."""
    return math.sqrt((city1[0] - city2[0])**2 + (city1[1] - city2[1])**2)


def total_distance(route, cities):
    """Calculates the total distance of a route."""
    total = 0
    for i in range(len(route) - 1):
        total += euclidean_distance(cities[route[i]], cities[route[i + 1]])
    total += euclidean_distance(cities[route[-1]], cities[route[0]])
    return total


def hill_climbing_tsp(cities, iterations):
    """Performs Hill Climbing algorithm for Traveling Salesman Problem."""
    current_route = random.sample(range(len(cities)), len(cities))
    current_distance = total_distance(current_route, cities)
    for _ in range(iterations):
        neighbor = current_route.copy()  # Create a copy to avoid modifying original
        i, j = random.sample(range(len(cities)), 2)
        neighbor[i], neighbor[j] = neighbor[j], neighbor[i]  # Swap cities
        neighbor_distance = total_distance(neighbor, cities)
        if neighbor_distance < current_distance:
            current_route = neighbor
            current_distance = neighbor_distance
    return current_route, current_distance


# Define cities with their coordinates (x, y)
cities = [(0, 0), (1, 3), (2, 1), (5, 2), (3, 4)]
iterations = 1000

route, distance = hill_climbing_tsp(cities, iterations)

print("Hill Climbing Route:", route)
print("Total Distance:", round(distance, 2))
