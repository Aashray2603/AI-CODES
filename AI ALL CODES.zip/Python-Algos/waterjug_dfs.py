class Node:
    def __init__(self, state, parent=None, action=None):
        self.state = state
        self.parent = parent
        self.action = action

def get_path(node):
    path = []
    while node.parent:
        path.append(node.action)
        node = node.parent
    path.reverse()
    return path

def dfs_water_jug(jug1_capacity, jug2_capacity, goal_quantity):
    stack = [Node((0, 0))]
    visited = set()

    while stack:
        current_node = stack.pop()
        visited.add(current_node.state)

        if goal_quantity in current_node.state:
            return get_path(current_node)

        jug1, jug2 = current_node.state

        if (0, jug2) not in visited:
            stack.append(Node((0, jug2), current_node, "Empty Jug 1"))
        if (jug1, 0) not in visited:
            stack.append(Node((jug1, 0), current_node, "Empty Jug 2"))
        if (jug1_capacity, jug2) not in visited:
            stack.append(Node((jug1_capacity, jug2), current_node, "Fill Jug 1"))
        if (jug1, jug2_capacity) not in visited:
            stack.append(Node((jug1, jug2_capacity), current_node, "Fill Jug 2"))

        if jug1 > 0:
            pour_jug1 = min(jug1, jug2_capacity - jug2)
            if (jug1 - pour_jug1, jug2 + pour_jug1) not in visited:
                stack.append(Node((jug1 - pour_jug1, jug2 + pour_jug1), current_node, f"Pour Jug 1 into Jug 2 ({pour_jug1})"))
        if jug2 > 0:
            pour_jug2 = min(jug2, jug1_capacity - jug1)
            if (jug1 + pour_jug2, jug2 - pour_jug2) not in visited:
                stack.append(Node((jug1 + pour_jug2, jug2 - pour_jug2), current_node, f"Pour Jug 2 into Jug 1 ({pour_jug2})"))

    return "No solution"

# Define the capacities of the jugs and the goal quantity
jug1_capacity = 4
jug2_capacity = 3
goal_quantity = 2

# Print the solution path
print(dfs_water_jug(jug1_capacity, jug2_capacity, goal_quantity))