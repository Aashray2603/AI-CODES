import random
import math


def euclidean_distance(city1, city2):
    """Calculates the Euclidean distance between two cities."""
    return math.sqrt((city1[0] - city2[0])**2 + (city1[1] - city2[1])**2)


def total_distance(route, cities):
    """Calculates the total distance of a route."""
    total = 0
    for i in range(len(route) - 1):
        total += euclidean_distance(cities[route[i]], cities[route[i + 1]])
    total += euclidean_distance(cities[route[-1]], cities[route[0]])
    return total


def simulated_annealing_tsp(cities, iterations, initial_temperature, cooling_rate):
    """Performs Simulated Annealing algorithm for TSP."""
    current_route = random.sample(range(len(cities)), len(cities))
    current_distance = total_distance(current_route, cities)
    temperature = initial_temperature
    for _ in range(iterations):
        i, j = random.sample(range(len(cities)), 2)
        neighbor = current_route.copy()
        neighbor[i], neighbor[j] = neighbor[j], neighbor[i]  # Swap cities
        neighbor_distance = total_distance(neighbor, cities)
        delta_e = neighbor_distance - current_distance  # Change in energy
        if delta_e < 0 or random.random() < math.exp(-delta_e / temperature):
            current_route = neighbor
            current_distance = neighbor_distance
        temperature *= cooling_rate
    return current_route, current_distance


# Define cities with their coordinates (x, y)
initial_temperature = 100
cooling_rate = 0.99
cities = [(0, 0), (1, 3), (2, 1), (5, 2), (3, 4)]
iterations = 1000

route, distance = simulated_annealing_tsp(cities, iterations, initial_temperature, cooling_rate)

print("Simulated Annealing Route:", route)
print("Total Distance:", round(distance,2))
