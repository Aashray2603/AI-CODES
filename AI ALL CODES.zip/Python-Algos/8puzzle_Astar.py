from heapq import heappop, heappush
from itertools import count


# Define goal state and heuristic function (Manhattan distance)
goal_state = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]


def manhattan_distance(state):
    distance = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] != 0:
                x, y = divmod(state[i][j] - 1, 3)
                distance += abs(x - i) + abs(y - j)
    return distance


def a_star_8_puzzle(initial_state):
    queue = [(manhattan_distance(initial_state), 0, initial_state, [])]
    visited = set()
    counter = count()
    while queue:
        cost, _, state, path = heappop(queue)
        if state == goal_state:
            return path
        visited.add(tuple(map(tuple, state)))
        zero_row, zero_col = next((i, j) for i, row in enumerate(state) for j, val in enumerate(row) if val == 0)

        for dr, dc, move in [(0, 1, "R"), (0, -1, "L"), (1, 0, "D"), (-1, 0, "U")]:
            new_row, new_col = zero_row + dr, zero_col + dc
            if 0 <= new_row < 3 and 0 <= new_col < 3:
                new_state = [list(row) for row in state]  # Copy the state
                new_state[zero_row][zero_col], new_state[new_row][new_col] = new_state[new_row][new_col], new_state[zero_row][zero_col]
                if tuple(map(tuple, new_state)) not in visited:
                    heappush(queue, (cost + 1 + manhattan_distance(new_state), next(counter), new_state, path + [move]))
    return "No solution"


# Define initial state of the puzzle
initial_state = [[1, 2, 3], [4, 5, 6], [0, 7, 8]]

# Print the solution path using A*
print("A* Solution Path:", a_star_8_puzzle(initial_state))
