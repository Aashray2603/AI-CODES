male(me).
male(father).
male(grandfather).
female(mother).
female(grandmother).

parent(father, me).
parent(mother, me).
parent(grandfather, father).
parent(grandmother, father).
parent(grandfather, mother).
parent(grandmother, mother).

father(X, Y) :- male(X), parent(X, Y).
mother(X, Y) :- female(X), parent(X, Y).
grandfather(X, Z) :- father(X, Y), parent(Y, Z).
grandmother(X, Z) :- mother(X, Y), parent(Y, Z).

sibling(X, Y) :- parent(Z, X), parent(Z, Y), X \= Y.
brother(X, Y) :- male(X), sibling(X, Y).
sister(X, Y) :- female(X), sibling(X, Y).

uncle(X, Y) :- brother(X, Z), parent(Z, Y).
aunt(X, Y) :- sister(X, Z), parent(Z, Y).
nephew(X, Y) :- male(X), (uncle(Y, X); aunt(Y, X)).
niece(X, Y) :- female(X), (uncle(Y, X); aunt(Y, X)).
cousin(X, Y) :- parent(Z, X), (sibling(Z, W), parent(W, Y); sibling(W, Z), parent(W,Y)).
