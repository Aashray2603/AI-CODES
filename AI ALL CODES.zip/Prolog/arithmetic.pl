sum_numbers(0, 0).
sum_numbers(N, Sum) :-
 N > 0,
 N1 is N - 1,
 sum_numbers(N1, SumN1),
 Sum is N + SumN1.
arithmetic_examples :-
 X is 5 + 3, % Addition
 Y is 10 - 4, % Subtraction
 Z is 6 * 2, % Multiplication
 W is 8 / 4, % Division
 write('Addition: '), write(X), nl,
 write('Subtraction: '), write(Y), nl,
 write('Multiplication: '), write(Z), nl,
 write('Division: '), write(W), nl.
example_sum_numbers :-
 N = 5,
 sum_numbers(N, Sum),
 write('Sum of numbers from 1 to '), write(N), write(': '), write(Sum), nl.
