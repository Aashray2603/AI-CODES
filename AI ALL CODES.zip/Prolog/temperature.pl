centigrade_to_fahrenheit(Centigrade, Fahrenheit) :-
 Fahrenheit is (Centigrade * 9/5) + 32.

below_freezing(Temperature) :-
 Temperature < 0.
