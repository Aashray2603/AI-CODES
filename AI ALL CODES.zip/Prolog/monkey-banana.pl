% Initial state: monkey is at door, holding no banana
at(door, monkey).
holding(nothing, monkey).

% Actions to move the monkey
move(state(middle, on_box, middle, has), grasp, state(middle, on_box, middle,
hasBanana)).
move(state(P, on_floor, P, H), climb, state(P, on_box, P, H)).
move(state(P1, on_floor, P1, H), push(P1, P2), state(P2, on_floor, P2, H)).

% Define the goal state
goal(state(_, _, _, hasBanana)).

% Predicate to achieve the goal
achieve_goal(State, []) :- goal(State).
achieve_goal(State1, [Move | Rest]) :-
 move(State1, Move, State2),
 achieve_goal(State2, Rest).
