% Rules to define parent relationships
parent(john, jim).
parent(john, ann).
parent(mary, jim).
parent(mary, ann).

% Rule to define the ancestor relationship using recursion
ancestor(X, Y) :- parent(X, Y).
ancestor(X, Y) :- parent(X, Z), ancestor(Z, Y).

% Rule using cut to stop backtracking and prune other solutions
ancestor_cut(X, Y) :- parent(X, Y).
ancestor_cut(X, Y) :- parent(X, Z), ancestor_cut(Z, Y), !.

% Rule using fail to deliberately fail and backtrack
never_succeed :- fail.
