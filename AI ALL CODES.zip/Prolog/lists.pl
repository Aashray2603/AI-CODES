% Create a List
create_list([1, 2, 3, 4, 5]).

% Write in List
write_in_list(Item, List, Result) :- append(List, [Item], Result).

% Check Membership
is_member(Item, List) :- member(Item, List).

% Length of a List
list_length(List, Length) :- length(List, Length).

% Reverse a List
reverse_list(List, Reversed) :- reverse(List, Reversed).

% Concatenation
concatenate_lists(List1, List2, Concatenated) :- append(List1, List2, Concatenated).

% Add an item
add_item(Item, List, Result) :- append(List, [Item], Result).

% Delete an item
delete_item(Item, List, Result) :- delete(List, Item, Result).

% Sub list
sub_list(Start, End, List, Sublist) :- sublist(Start, End, List, Sublist).
sublist(_, 0, _, []).
sublist(Start, End, [_ | Tail], Sublist) :- NewStart is Start - 1, NewEnd is End - 1,
sublist(NewStart, NewEnd, Tail, Sublist).
sublist(Start, End, [Head | Tail], [Head | Sublist]) :- Start > 0, NewStart is Start - 1,
NewEnd is End - 1, sublist(NewStart, NewEnd, Tail, Sublist).

% Permutations
list_permutations(List, Permutations) :- permutation(List, Permutations).

% Append List
append_list(List1, List2, Result) :- append(List1, List2, Result).
% Finding nth element
nth_element(N, List, Element) :- nth0(N, List, Element).
