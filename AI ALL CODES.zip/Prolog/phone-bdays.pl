contact('Ram', '123-456-7890', '1990-02-15').
contact('Sita', '987-654-3210', '1995-08-23').
contact('Laxman', '555-123-4567', '1988-02-05').
contact('Krishna', '444-567-8901', '1992-12-10').

birthdays_in_current_month(Names) :-
 get_time(Timestamp),
 stamp_date_time(Timestamp, DateTime, 'local'),
 date_time_value(month, DateTime, Month),
 findall(Name, (contact(Name, _, Birthday), birthday_in_month(Birthday, Month)),
Names).
birthday_in_month(Birthday, Month) :-
 split_string(Birthday, '-', '', [_, BM, _]),
 atom_number(BM, Month).
