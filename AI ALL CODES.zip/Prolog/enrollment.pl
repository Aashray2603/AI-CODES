% Declare student predicate as dynamic
:- dynamic student/3, course/3 .

% Define student and course facts
student(semester(1), [cs101, math101]).
student(semester(2), [cs202, math203]).
student(semester(3), [cs303, physics101]).
student(semester(4), [cs404, english101]).

student(ram, [cs101, math101]).
student(shyam, [cs202, math203]).
student(riya, [cs303, physics101]).
student(amit, [cs404, english101]).

course(cs101, 'Introduction to Computer Science', 3).
course(math101, 'Calculus I', 3).
course(cs202, 'Data Structures and Algorithms', 3).
course(math203, 'Calculus II', 3).
course(cs303, 'Database Systems', 3).
course(physics101, 'Introduction to Physics', 3).
course(cs404, 'Operating Systems', 3).
course(english101, 'Introduction to English Literature', 3).

% Rule to check course capacity
course_capacity(CourseCode, Capacity) :-
    course(CourseCode, _, Capacity).

% Rule to check if student is enrolled in a course
enrolled(Student, CourseCode) :-
    student(Student, Courses),
    member(CourseCode, Courses).

% Rule to enroll student in a course if capacity permits
enroll_student(Student, CourseCode) :-
    \not(enrolled(Student, CourseCode)),  % Check not already enrolled
    course_capacity(CourseCode, Capacity),
    Capacity > 0,  % Check if any seat available
    CapacityNew is Capacity - 1,
    retractall(course(CourseCode, _, _)),  % Remove old course info
    assert(course(CourseCode, _, CapacityNew)),  % Update course capacity
    assert(enrolled(Student, [CourseCode])).  % Enroll student

% Rule to display all enrolled courses for a student
show_enrolled_courses(Student) :-
    student(Student, Courses),
    write('Enrolled Courses: '), nl,
    (   member(CourseCode, Courses),
        course(CourseCode, CourseName, _),
        write(' - '), write(CourseName), nl
    ).

