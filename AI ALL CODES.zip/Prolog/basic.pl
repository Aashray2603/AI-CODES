% Facts
mammal(cat).
mammal(dog).
mammal(human).

% Rules
is_mammal(X) :- mammal(X).
