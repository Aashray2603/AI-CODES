% Define the initial state of the jugs
initial_state(0, 0).

% Define the capacities of the jugs
capacity(5, 3).

% Define the goal state of the jugs
goal_state(4, _).

% Define the possible operations
operation(fill_jug1, (J1, J2), (5, J2)) :- J1 < 5.
operation(fill_jug2, (J1, J2), (J1, 3)) :- J2 < 3.
operation(empty_jug1, (J1, J2), (0, J2)) :- J1 > 0.
operation(empty_jug2, (J1, J2), (J1, 0)) :- J2 > 0.
operation(pour_jug1_to_jug2, (J1, J2), (J1_new, J2_new)) :-
    J1 > 0, J2 < 3,
    Diff is min(J1, 3 - J2),
    J1_new is J1 - Diff,
    J2_new is J2 + Diff.
operation(pour_jug2_to_jug1, (J1, J2), (J1_new, J2_new)) :-
    J2 > 0, J1 < 5,
    Diff is min(J2, 5 - J1),
    J1_new is J1 + Diff,
    J2_new is J2 - Diff.

% Define the recursive solution predicate using breadth-first search
solve_bfs(Queue, []) :- Queue = [(State, Path)|_], goal_state(State, _), reverse(Path, Path).
solve_bfs(Queue, Solution) :-
    Queue = [(State, Path)|Rest],
    findall((NextState, [Operation|Path]), (operation(Operation, State, NextState), \+ member(NextState, Path)), NextStates),
    append(Rest, NextStates, NewQueue),
    solve_bfs(NewQueue, Solution).

% Define the main predicate to solve the water jug problem using breadth-first search
main :- initial_state(J1, J2), solve_bfs([(J1, J2, [])], Solution), write(Solution).
