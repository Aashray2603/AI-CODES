fib(0, 0).
fib(1, 1).
fib(N, Result) :-
 N > 1,
 N1 is N - 1,
 N2 is N - 2,
 fib(N1, Result1),
 fib(N2, Result2),
 Result is Result1 + Result2.
display_fibonacci_series(N) :-
 display_fibonacci_series_helper(0, N).
display_fibonacci_series_helper(Current, N) :-
 Current =< N,
 fib(Current, Result),
 write(Result), write(' '),
 Next is Current + 1,
 display_fibonacci_series_helper(Next, N).
