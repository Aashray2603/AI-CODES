% Initial state: 3 missionaries, 3 cannibals, and boat on the left bank
initial_state(state(3, 3, left, 0, 0)).
% Goal state: 0 missionaries, 0 cannibals, and boat on the right bank
goal_state(state(0, 0, right, _, _)).
% Valid state conditions
valid_state(state(M, C, _, _, _)) :-
 M >= 0, C >= 0, M =< 3, C =< 3,
 (M = 0 ; M >= C), % Missionaries can't be outnumbered by cannibals
 (M = 3 ; M >= 3 - C). % Avoids unnecessary backtracking
% Move boat from left to right
move(state(M1, C1, left, M2, C2), move(M, C), state(M3, C3, right, M4, C4)) :-
 M =< M1, C =< C1, M2 is M1 - M, C2 is C1 - C,
 M3 is M2, C3 is C2, M4 is M + M2, C4 is C + C2, valid_state(state(M3, C3, right,
M4, C4)).
% Move boat from right to left
move(state(M1, C1, right, M2, C2), move(M, C), state(M3, C3, left, M4, C4)) :-
 M =< M2, C =< C2, M1 is M2 - M, C1 is C2 - C,
 M3 is M2, C3 is C2, M4 is M + M1, C4 is C + C1, valid_state(state(M3, C3, left,
M4, C4)).
% Recursive predicate to find a solution
solve(State, _, []) :- goal_state(State).
solve(State, Visited, [Move | Rest]) :-
 move(State, Move, NextState),
 \+ member(NextState, Visited),
 solve(NextState, [NextState | Visited], Rest).
% Example query to find a solution
% ?- initial_state(InitialState), solve(InitialState, [InitialState], Solution).
