:- dynamic book/4, author/2, borrower/2, borrowed/4.

% Book data
book(1, 'The Great Gatsby', 'F. Scott Fitzgerald', fiction).
book(2, 'To Kill a Mockingbird', 'Harper Lee', fiction).
book(3, 'The Catcher in the Rye', 'J.D. Salinger', fiction).
book(4, 'The Lord of the Rings', 'J.R.R. Tolkien', fiction).
book(5, 'The Art of Computer Programming', 'Donald E. Knuth', non_fiction).

% Author data
author('F. Scott Fitzgerald', american).
author('Harper Lee', american).
author('J.D. Salinger', american).
author('J.R.R. Tolkien', british).
author('Donald E. Knuth', american).

% Borrower data
borrower(1, 'John Doe').
borrower(2, 'Jane Smith').
borrower(3, 'Bob Johnson').

% Borrowed books
borrowed(1, 1, '2024-04-20', '2024-05-05').
borrowed(2, 4, '2024-04-15', '2024-05-01').

% Predicates for querying the database

% Find a book by ID
find_book(Id, Title, Author, Genre) :-
    book(Id, Title, Author, Genre).

% Find an author by name
find_author(Name, Nationality) :-
    author(Name, Nationality).

% Check if a book is borrowed
is_borrowed(BookId) :-
    borrowed(_, BookId, _, _).

% Add a new book
add_book(Id, Title, Author, Genre) :-
    assertz(book(Id, Title, Author, Genre)).

% Add a new borrower
add_borrower(Id, Name) :-
    assertz(borrower(Id, Name)).

% Borrow a book
borrow_book(BorrowerId, BookId, StartDate, DueDate) :-
    \+ is_borrowed(BookId),
    assertz(borrowed(BorrowerId, BookId, StartDate, DueDate)).

% Return a borrowed book
return_book(BorrowerId, BookId) :-
    retract(borrowed(BorrowerId, BookId, _, _)).
