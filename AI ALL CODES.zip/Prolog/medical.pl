% Facts
symptom(fever).
symptom(cough).
symptom(sneezing).
symptom(runny_nose).
disease(flu, [fever, cough]).
disease(cold, [sneezing, runny_nose]).
% Rules
has_disease(Patient, Disease) :-
 findall(Symptom, (symptom(Symptom), ask_symptom(Patient, Symptom)),
Symptoms),
 disease(Disease, DiseaseSymptoms),
 subset(DiseaseSymptoms, Symptoms).
ask_symptom(Patient, Symptom) :-
 write('Does '), write(Patient), write(' have '), write(Symptom), write('? (yes/no) '),
 read(Response),
 Response = yes.
